const express = require("express");
const cors = require("cors");
const userRouter = require("./routes/user.routes");
const postRouter = require("./routes/post.routes");
var path = require("path");
const app = express();

//app.use(cors());
app.use(
  cors({
    origin: "*",
  })
);
app.use(express.json());
app.use("/api", userRouter);
app.use("/api", postRouter);
app.use("/image", express.static(path.join(__dirname, "uploads")));
app.use(express.static("../uploads"));

app.listen(8000, () => {
  console.log("running on port 8000");
});
