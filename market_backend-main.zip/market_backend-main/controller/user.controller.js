const db = require("../db");

class UserController {
  async createUser(req, res) {
    console.log(req.body);
    const { username, name, surname } = req.body;
    const newUser = await db.query(
      `INSERT INTO "user" (username, name, surname) VALUES ($1, $2, $3) RETURNING *`,
      [username, name, surname]
    );
    res.json(newUser.rows[0]);
  }
  async getUsers(req, res) {
    const users = await db.query(`SELECT * FROM "user"`);
    res.json(users.rows);
  }
  async getUser(req, res) {
    const userId = req.params.id;
    const user = await db.query(`SELECT * FROM "user" WHERE id = $1`, [userId]);
    res.json(user.rows);
  }
  async updateUser(req, res) {}
  async deleteUser(req, res) {}
}

module.exports = new UserController();
