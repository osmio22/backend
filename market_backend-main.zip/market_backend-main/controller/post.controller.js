const db = require("../db");

class PostController {
  async createPost(req, res) {
    res.header("Access-Control-Allow-Origin", "*");
    console.log(req.body);
    const { title, user_id } = req.body;

    const newPost = await db.query(
      `INSERT INTO "post" (title, user_id) VALUES ($1, $2) RETURNING *`,
      [title, user_id]
    );
    res.json(newPost.rows[0]);
  }

  async getPosts(req, res) {
    let postResponse = [];
    const posts = await db.query(`SELECT * FROM "post"`);

    let getPostInfo = posts.rows.map(async (post) => {
      const postUser = await db.query(`SELECT * FROM "user" where id = $1`, [
        post.user_id,
      ]);
      const postImages = await db.query(
        `SELECT * FROM "postImages" where post_id = $1`,
        [post.id]
      );
      post.user = [postUser.rows[0]];
      post.images = [...postImages.rows];
      postResponse.push(post);
    });

    Promise.all(getPostInfo).then(function () {
      res.json(postResponse);
    });
  }

  async getPost(req, res) {
    const postId = req.params.id;
    const post = await db.query(`SELECT * FROM "post" WHERE id = $1`, [postId]);
    res.json(post.rows);
  }
  async updatePost(req, res) {}
  async deletePost(req, res) {}

  //IMAGES SECTION
  async createPostImage(req, res) {
    const { orig_name, post_id } = req.body;
    console.log(req.file);
    const filename = req.file.filename;
    const newPostImage = await db.query(
      `INSERT INTO "postImages" (filename, orig_name, post_id) VALUES ($1, $2, $3) RETURNING *`,
      [filename, orig_name, post_id]
    );
    res.json(newPostImage.rows[0]);
  }
}

module.exports = new PostController();
