
create TABLE "user"(
    id SERIAL PRIMARY KEY,
    username VARCHAR(255),
    name VARCHAR(255),
    surname VARCHAR(255)
);

create TABLE "post"(
    id SERIAL PRIMARY KEY,
    title VARCHAR(255),
    user_id SERIAL,
    FOREIGN KEY (user_id) REFERENCES "user" (id)
);

create TABLE "postImages"(
    id SERIAL PRIMARY KEY,
    filename VARCHAR(255),
    orig_name VARCHAR(255),
    post_id SERIAL,
    FOREIGN KEY (post_id) REFERENCES "post" (id)
);


ALTER TABLE "user" ADD UNIQUE (username);

ALTER TABLE "postImages"
ADD COLUMN image_file bytea;

ALTER TABLE "postImages"  
DROP COLUMN image_file;

ALTER TABLE "postImages" ADD UNIQUE (filename);

ALTER TABLE "user"
ADD COLUMN user_image VARCHAR(255) UNIQUE;

ALTER TABLE "post"  
ADD COLUMN description TEXT;