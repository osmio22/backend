const Router = require("express");
const router = new Router();
const postController = require("../controller/post.controller");
const multer = require("multer");
var path = require("path");
const { nextTick } = require("process");

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "./uploads");
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + path.extname(file.originalname));
  },
});

const upload = multer({
  storage: storage,
  limits: { fieldSize: 10 * 1024 * 1024 },
});

router.post("/post", postController.createPost);
router.get("/post", postController.getPosts);
router.get("/post/:id", postController.getPost);
router.put("/post", postController.updatePost);
router.delete("/post/:id", postController.deletePost);

//IMAGE SECTION

router.post(
  "/post/image",
  upload.single("image_file"),
  postController.createPostImage
);

module.exports = router;
